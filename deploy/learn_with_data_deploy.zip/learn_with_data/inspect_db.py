"""
Database Inspection Utility for Consistency Pulse.
Run anytime with:
    python inspect_db.py
"""

import sqlite3
import os
import sys

# Ensure UTF-8 output on Windows terminals
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from config import Config
DB_PATH = Config.DATABASE_PATH

def print_separator(title=""):
    print("\n" + "=" * 25 + f" {title} " + "=" * 25)

def inspect():
    if not os.path.exists(DB_PATH):
        print(f"[!] Database file not found at: {DB_PATH}")
        return

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # 1. Database Overview
    print_separator("DATABASE OVERVIEW")
    print(f"[*] Database File: {DB_PATH}")
    file_size_kb = round(os.path.getsize(DB_PATH) / 1024, 2)
    print(f"[*] File Size: {file_size_kb} KB")

    # Tables count
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence';")
    tables = [row["name"] for row in cursor.fetchall()]
    print(f"[*] Tables Found: {', '.join(tables)}")

    for t in tables:
        cursor.execute(f"SELECT COUNT(*) as cnt FROM {t};")
        cnt = cursor.fetchone()["cnt"]
        print(f"    - {t}: {cnt} rows")

    # 2. Users Table
    print_separator("USERS REGISTERED")
    cursor.execute("SELECT id, username, email, role, created_at, last_login FROM users;")
    users = cursor.fetchall()
    print(f"{'ID':<4} | {'Username':<12} | {'Role':<8} | {'Email':<28} | {'Created At'}")
    print("-" * 75)
    for u in users:
        print(f"{u['id']:<4} | {u['username']:<12} | {u['role']:<8} | {u['email']:<28} | {u['created_at']}")

    # 3. Aggregates by Language
    print_separator("AGGREGATES BY LANGUAGE")
    cursor.execute("""
        SELECT language, COUNT(*) as sessions, ROUND(SUM(hours_spent), 1) as total_hours, 
               SUM(concepts_count) as total_concepts, ROUND(AVG(mastery_score), 2) as avg_mastery
        FROM learning_logs
        GROUP BY language
        ORDER BY total_hours DESC;
    """)
    langs = cursor.fetchall()
    print(f"{'Language':<18} | {'Sessions':<9} | {'Total Hours':<12} | {'Concepts':<9} | {'Avg Mastery'}")
    print("-" * 72)
    for l in langs:
        print(f"{l['language']:<18} | {l['sessions']:<9} | {str(l['total_hours']) + ' hrs':<12} | {l['total_concepts']:<9} | {l['avg_mastery']} / 5")

    # 4. Recent 10 Learning Logs
    print_separator("LATEST 10 LEARNING SESSIONS")
    cursor.execute("""
        SELECT l.id, u.username, l.date, l.language, l.topic, l.hours_spent, l.concepts_count, l.mastery_score
        FROM learning_logs l
        JOIN users u ON l.user_id = u.id
        ORDER BY l.date DESC, l.id DESC
        LIMIT 10;
    """)
    logs = cursor.fetchall()
    print(f"{'ID':<5} | {'User':<10} | {'Date':<10} | {'Stack':<12} | {'Hours':<6} | {'Mastery':<7} | {'Topic'}")
    print("-" * 85)
    for row in logs:
        topic_preview = row['topic'][:35] + ("..." if len(row['topic']) > 35 else "")
        print(f"{row['id']:<5} | {row['username']:<10} | {row['date']:<10} | {row['language']:<12} | {row['hours_spent']:<6} | {row['mastery_score']}/5    | {topic_preview}")

    # 5. Recent Sync Audits
    print_separator("LATEST SYNC AUDITS")
    cursor.execute("""
        SELECT id, sync_type, records_count, file_name, status, created_at
        FROM sync_audit
        ORDER BY id DESC
        LIMIT 5;
    """)
    syncs = cursor.fetchall()
    if syncs:
        for s in syncs:
            print(f"[{s['created_at']}] Type: {s['sync_type']} | Records: {s['records_count']} | Target: {s['file_name']} | Status: {s['status']}")
    else:
        print("No sync audit records yet.")

    print("\n" + "=" * 65 + "\n")
    conn.close()

if __name__ == "__main__":
    inspect()
